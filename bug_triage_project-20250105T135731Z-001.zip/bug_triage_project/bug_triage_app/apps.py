from django.apps import AppConfig


class BugTriageAppConfig(AppConfig):
    name = 'bug_triage_app'
